import square from './square';
import sum from './sum';

document.writeln('The sum of 5 and 8 is ' + sum(5, 8) + '<br>');
document.writeln('The square of 6 is ' + square(6) + '<br>');